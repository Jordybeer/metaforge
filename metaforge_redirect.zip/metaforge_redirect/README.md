# Metaforge — Local Kiosk Redirect

Drop this folder into Vercel as a new project (Static site — no framework needed).

## Setup
1. `vercel --prod` or drag-and-drop folder to vercel.com/new
2. Assign your custom subdomain under Project → Settings → Domains
3. Replace `bg.jpg` with your own background if desired (1920x1080 recommended)

## Redirect target
`https://metaforge.app/profile/jordy.bear-4045?game=arc-raiders`
